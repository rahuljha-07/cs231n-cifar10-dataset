from builtins import range
import numpy as np



def affine_forward(x, w, b):
    """
    Computes the forward pass for an affine (fully-connected) layer.

    The input x has shape (N, d_1, ..., d_k) and contains a minibatch of N
    examples, where each example x[i] has shape (d_1, ..., d_k). We will
    reshape each input into a vector of dimension D = d_1 * ... * d_k, and
    then transform it to an output vector of dimension M.

    Inputs:
    - x: A numpy array containing input data, of shape (N, d_1, ..., d_k)
    - w: A numpy array of weights, of shape (D, M)
    - b: A numpy array of biases, of shape (M,)

    Returns a tuple of:
    - out: output, of shape (N, M)
    - cache: (x, w, b)
    """
    out = None
    ###########################################################################
    # TODO: Implement the affine forward pass. Store the result in out. You   #
    # will need to reshape the input into rows.                               #
    ###########################################################################
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    #Reshape the input x to (N, D), where D is the input size that has been flattened and N is the number of samples.
    x_flattened = x.reshape((x.shape[0], -1))

    # Calculate the transformation affine to (N, D). * (D, M) -> (N, M) + (M,)
    out = x_flattened.dot(w) + b

    # pass

    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    cache = (x, w, b)
    return out, cache


def affine_backward(dout, cache):
    """
    Computes the backward pass for an affine layer.

    Inputs:
    - dout: Upstream derivative, of shape (N, M)
    - cache: Tuple of:
      - x: Input data, of shape (N, d_1, ... d_k)
      - w: Weights, of shape (D, M)
      - b: Biases, of shape (M,)

    Returns a tuple of:
    - dx: Gradient with respect to x, of shape (N, d1, ..., d_k)
    - dw: Gradient with respect to w, of shape (D, M)
    - db: Gradient with respect to b, of shape (M,)
    """
    x, w, b = cache
    dx, dw, db = None, None, None
    ###########################################################################
    # TODO: Implement the affine backward pass.                               #
    ###########################################################################
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    # pass

    # to match the forward pass, reshape input x to (N, D), where N is the number of samples
    #D is the input size (product of input dimensions) that has been flattened.

    x_flattened = x.reshape((x.shape[0], -1))

    # Calculate the gradient (dx) in relation to x.
    # Since #dout has the shape (N, M) and w.T. has the shape (M, D), their product yields (N, D),
    # which is subsequently reshaped to its original form of x.

    dx = dout.dot(w.T).reshape(x.shape)

    # Calculate the gradient (dw) in relation to w.
    # x_flattened.The product of T's shape (D, N) and Dout's shape (N, M) yields (D, M), 
    # which is the gradient's shape for W.

    dw = x_flattened.T.dot(dout)

    # Calculate the gradient (db) in relation to b.
    # To find the gradient of b, add the upstream derivative dout over the batch dimension (axis 0). 
    # The shape of the outcome (M,) is the same as the bias vector's shape.

    db = np.sum(dout, axis=0)


    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    return dx, dw, db


def relu_forward(x):
    """
    Computes the forward pass for a layer of rectified linear units (ReLUs).

    Input:
    - x: Inputs, of any shape

    Returns a tuple of:
    - out: Output, of the same shape as x
    - cache: x
    """
    out = None
    ###########################################################################
    # TODO: Implement the ReLU forward pass.                                  #
    ###########################################################################
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    # pass
    #takes the maximun value 
    out = np.maximum(0,x)

    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    cache = x
    return out, cache


def relu_backward(dout, cache):
    """
    Computes the backward pass for a layer of rectified linear units (ReLUs).

    Input:
    - dout: Upstream derivatives, of any shape
    - cache: Input x, of same shape as dout

    Returns:
    - dx: Gradient with respect to x
    """
    dx, x = None, cache
    ###########################################################################
    # TODO: Implement the ReLU backward pass.                                 #
    ###########################################################################
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    # pass
    # Gradient is passed only where x > 0; else it is zero.
    dx = (x > 0) * dout


    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    return dx


def svm_loss(x, y):
    """
    Computes the loss and gradient using for multiclass SVM classification.

    Inputs:
    - x: Input data, of shape (N, C) where x[i, j] is the score for the jth
      class for the ith input.
    - y: Vector of labels, of shape (N,) where y[i] is the label for x[i] and
      0 <= y[i] < C

    Returns a tuple of:
    - loss: Scalar giving the loss
    - dx: Gradient of the loss with respect to x
    """
    loss, dx = None, None
    ###########################################################################
    # TODO: Implement loss and gradient for multiclass SVM classification.    #
    # This will be similar to the svm loss vectorized implementation in       #
    # cs231n/classifiers/linear_svm.py.                                       #
    ###########################################################################
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    # pass

    num_train = x.shape[0]  # Number of training samples

    # Subtract the proper class score from the total loss for each class, then add one.
    loss = x.T - x[np.arange(num_train), y] + 1  
    loss[y, np.arange(num_train)] = 0  # Set the loss for the correct class to zero

    # Create the gradient mask: 1 for positive losses, 0 for others.
    dx = (loss > 0).astype(int).T  

    # Calculate the average loss for positive margins.
    loss = np.sum(loss, where=loss > 0) / num_train  

    # Compute gradients and negate for the appropriate class.
    dx[np.arange(num_train), y] = np.sum(dx, axis=1) * (-1)  

    # Average gradients throughout the quantity of training cases.
    dx = dx / num_train  


    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    return loss, dx


def softmax_loss(x, y):
    """
    Computes the loss and gradient for softmax classification.

    Inputs:
    - x: Input data, of shape (N, C) where x[i, j] is the score for the jth
      class for the ith input.
    - y: Vector of labels, of shape (N,) where y[i] is the label for x[i] and
      0 <= y[i] < C

    Returns a tuple of:
    - loss: Scalar giving the loss
    - dx: Gradient of the loss with respect to x
    """
    loss, dx = None, None
    ###########################################################################
    # TODO: Implement the loss and gradient for softmax classification. This  #
    # will be similar to the softmax loss vectorized implementation in        #
    # cs231n/classifiers/softmax.py.                                          #
    ###########################################################################
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    # pass

    num_train = x.shape[0]  # Number of training samples
    ex = np.exp(x)  # Compute the exponentials of the scores
    p = (ex.T / np.sum(ex, axis=1)).T  # Calculate softmax probabilities
    
    # Calculate the loss as the incorrect class's negative log probability.
    loss = -np.sum(np.log(p[np.arange(num_train), y])) / num_train  
    dx = np.copy(p)  # Initialize gradient with probabilities
    dx[np.arange(num_train), y] -= 1  # Subtract 1 from the correct class
    dx = dx / num_train  # Average the gradients


    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    return loss, dx
